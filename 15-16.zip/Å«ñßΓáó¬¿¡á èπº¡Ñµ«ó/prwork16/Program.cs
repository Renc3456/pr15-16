﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace prwork16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Практическая работа 16");
            Console.WriteLine("Выполнили Кузнецов Артем и Подставкина Виолетта");
            Console.WriteLine("Вариант 2");
            Console.WriteLine();

            StreamReader sr = new StreamReader(@"input.txt", Encoding.Default);
            STUDENT student = new STUDENT();
            student.InputFromFile(sr);
            if (student.Mathematics == 3|| student.Mathematics == 4)
            {
                Console.WriteLine(student.PrintInfo());
                student.Save();
            }

            else if (student.EnglishLanguage == 3 || student.EnglishLanguage == 4)
            {
                Console.WriteLine(student.PrintInfo());
                student.Save();
            }

            else if (student.Literature == 3 || student.Literature == 4)
            {
                Console.WriteLine(student.PrintInfo());
                student.Save();
            }

            else if (student.Biology == 3 || student.Biology == 4)
            {
                Console.WriteLine(student.PrintInfo());
                student.Save();
            }

            else if (student.PhysicalCulture == 3 || student.PhysicalCulture == 4)
            {
                Console.WriteLine(student.PrintInfo());
                student.Save();
            }

            else
            {
                Console.WriteLine("нет студента с оценкой 3 или 4");
            }



            Console.ReadKey();
        }
    }
}
