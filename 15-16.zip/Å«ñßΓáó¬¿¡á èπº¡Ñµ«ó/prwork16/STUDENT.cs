﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace prwork16
{
    internal class STUDENT
    {
        private string second_name;
        private string id_group;
        private int mathematics;
        private int english_language;
        private int literature;
        private int biology;
        private int physical_culture;

        public string SecondName
        {
            get { return second_name; }
            set { second_name = value; }
        }
        public string IDGroup
        {
            get { return id_group; }
            set { id_group = value; }
        }
        public int Mathematics
        {
            get { return mathematics; }
            set { mathematics = value; }
        }
        public int EnglishLanguage
        {
            get { return english_language; }
            set { english_language = value; }
        }
        public int Literature
        {
            get { return literature; }
            set { literature = value; }
        }
        public int Biology
        {
            get { return biology; }
            set { biology = value; }
        }
        public int PhysicalCulture
        {
            get { return physical_culture; }
            set { physical_culture = value; }
        }

        public STUDENT()
        {
            second_name = "не задано"; 
            id_group = "не задано";
            mathematics = 0;
            english_language = 0;
            literature = 0;
            biology = 0;
            physical_culture = 0;
        }

        public STUDENT(string Sname, string group, int math, int eng, int lit, int bio, int phys)
        {
            second_name = Sname;
            id_group = group;
            mathematics = math;
            english_language = eng;
            literature = lit;
            biology = bio;
            physical_culture = phys;
        }

        public string PrintInfo()
        {
            return $"фамилия: {second_name} " +
                $"группа: {id_group} " +
                $"оценка по математике: {mathematics} " +
                $"оценка по англ: {english_language} " +
                $"оценка по литературе: {literature} " +
                $"оценка по биологии:{biology} " +
                $"оценка по физре:{physical_culture} ";
        }

        public void New_Student()
        {
                Console.WriteLine("Введите фамилию и инициалы студента");
                this.SecondName = Console.ReadLine();
                Console.WriteLine("Введите группу студента");
                this.IDGroup = Console.ReadLine();
                Console.WriteLine("Введите оценку по математике ");
                this.Mathematics = int.Parse(Console.ReadLine());
                Console.WriteLine("Введите оценку по английскому языку ");
                this.EnglishLanguage = int.Parse(Console.ReadLine());
                Console.WriteLine("Введите оценку по литературе ");
                this.Literature = int.Parse(Console.ReadLine());
                Console.WriteLine("Введите оценку по Биологии ");
                this.Biology = int.Parse(Console.ReadLine());
                Console.WriteLine("Введите оценку по физре ");
                this.PhysicalCulture = int.Parse(Console.ReadLine());
        }

        public void av_bal()
        {
            double bal = (mathematics + english_language + literature + Biology + PhysicalCulture)/5.0;
            Console.WriteLine($"Средний балл студента = {bal}");
        }
        public void InputFromFile(StreamReader sr)
        {
                string input = sr.ReadLine();
                string[] info = input.Split(';');
                SecondName = info[0];
                IDGroup = info[1];
                Mathematics = int.Parse(info[2]);
                EnglishLanguage = int.Parse(info[3]);
                Literature = int.Parse(info[4]);
                Biology = int.Parse(info[5]);
                PhysicalCulture = int.Parse(info[6]);
        }
        public void Save()
        {
            StreamWriter sr = new StreamWriter(@"Result.txt", false);
            sr.WriteLine($"{SecondName};{IDGroup};{Mathematics};{EnglishLanguage};{Literature};{Biology};{PhysicalCulture}");
            sr.Close();
            Console.WriteLine("сохранение в файл выполнено");
        }

    }
}
