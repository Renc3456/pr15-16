﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PR15_16
{
    class STUDENT
    {
        private string name;
        private string group;
        private int math;
        private int history;
        private int physics;
        private int obzh;
        private int french;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Group
        {
            get { return group; }
            set { group = value; }
        }
        public int Math
        {
            get { return math; }
            set { math = value; }
        }
        public int History
        {
            get { return history; }
            set { history = value; }
        }
        public int Physics
        {
            get { return physics; }
            set { physics = value; }
        }
        public int Obzh
        {
            get { return obzh; }
            set { obzh = value; }
        }
        public int French
        {
            get { return french; }
            set { french = value; }
        }

        public STUDENT()
        {
            name = "не задано";
            group = "не задано";
            math = 0;
            history = 0;
            physics = 0;
            obzh = 0;
            french = 0;
        }

        public STUDENT(string n, string g, int m, int h, int p, int o, int f)
        {
            name = n;
            this.group = g;
            this.math = m;
            history = h;
            physics = p;
            obzh = o;
            french = f;
        }

        public string PrintInfo()
        {
            return $"фамилия: {name} " +
                $"группа: {group} " +
                $"оценка по математике: {math} " +
                $"оценка по истории: {history} " +
                $"оценка по физике: {physics} " +
                $"оценка по обж:{obzh} " +
                $"оценка по французкому:{french} ";
        }

        public void New_Student()
        {
            Console.WriteLine("Введите фамилию и инициалы студента");
            this.Name = Console.ReadLine();
            Console.WriteLine("Введите группу студента");
            this.Group = Console.ReadLine();
            Console.WriteLine("Введите оценку по математике ");
            this.Math = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите оценку по истории ");
            this.History = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите оценку по физике ");
            this.Physics = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите оценку по обж ");
            this.Obzh = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите оценку по французкому ");
            this.French = int.Parse(Console.ReadLine());
        }

        public void av_bal()
        {
            double bal = (math + history + physics + Obzh + French) / 5.0;
            Console.WriteLine($"Средний балл студента = {bal}");
        }
        public void InputFromFile(StreamReader sr)
        {
            string input = sr.ReadLine();
            string[] info = input.Split(';');
            Name = info[0];
            Group = info[1];
            Math = int.Parse(info[2]);
            History = int.Parse(info[3]);
            Physics = int.Parse(info[4]);
            Obzh = int.Parse(info[5]);
            French = int.Parse(info[6]);
        }
        public void Save()
        {
            StreamWriter sr = new StreamWriter(@"Result.txt", false);
            sr.WriteLine($"{Name};{Group};{Math};{History};{Physics};{Obzh};{French}");
            sr.Close();
            Console.WriteLine("сохранение в файл выполнено");
        }
    }
}
